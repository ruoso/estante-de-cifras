# Partida

```
[C] 
Hoje eu vou pra bem longe
```
