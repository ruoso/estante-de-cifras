# Partida

```
[C] 
Hoje eu vou pra longe
```
