# Quinta no Coreto

```
[D] 
A banda toca no coreto
```
