Um caderno de rodas de quinta, sem nome ainda.
